/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';

interface ContentDisplayProps {
  content: string;
  isLoading: boolean;
  onWordClick: (word: string) => void;
  knownTopics: string[];
}

const InteractiveContent: React.FC<{
  content: string;
  onWordClick: (word: string) => void;
  knownTopics: string[];
}> = ({ content, onWordClick, knownTopics }) => {
  // Create a map for quick, case-insensitive lookup of the canonical topic name.
  const topicMap = React.useMemo(() => {
    const map = new Map<string, string>();
    for (const topic of knownTopics) {
      map.set(topic.toLowerCase(), topic);
    }
    return map;
  }, [knownTopics]);

  // Sort topics by length descending to match longer phrases first (e.g., "High Atlas" before "Atlas").
  // Then, build a regex to find all known topics in the content.
  const tokenizerRegex = React.useMemo(() => {
    if (knownTopics.length === 0) return null;
    const sortedTopics = [...knownTopics].sort((a, b) => b.length - a.length);
    const escapedTopics = sortedTopics.map(topic =>
      topic.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') // Escape special regex characters
    );
    // The regex captures the matched topic, so split() will include it in the result array.
    return new RegExp(`(${escapedTopics.join('|')})`, 'gi');
  }, [knownTopics]);

  if (!tokenizerRegex) {
    // Fallback for when there are no known topics, though unlikely.
    // This part re-implements the original behavior of making every word clickable.
    return (
        <p style={{ margin: 0 }}>
            {content.split(/(\s+)/).map((word, index) => {
                 if (/\S/.test(word)) {
                    const cleanWord = word.replace(/[.,!?;:()"']/g, '');
                    return (
                        <button
                            key={index}
                            onClick={() => onWordClick(cleanWord)}
                            className="interactive-word"
                            aria-label={`Learn more about ${cleanWord}`}
                        >
                            {word}
                        </button>
                    );
                 }
                 return <span key={index}>{word}</span>
            })}
        </p>
    );
  }

  const parts = content.split(tokenizerRegex).filter(Boolean);

  return (
    <p style={{ margin: 0 }}>
      {parts.map((part, index) => {
        const canonicalTopic = topicMap.get(part.toLowerCase());

        if (canonicalTopic) {
          // This part is a known multi-word topic. Render as a single button.
          return (
            <button
              key={`${index}-${canonicalTopic}`}
              onClick={() => onWordClick(canonicalTopic)}
              className="interactive-word known-topic"
              aria-label={`Learn more about ${canonicalTopic}`}
            >
              {part}
            </button>
          );
        } else {
          // This part is regular text. Split it into words and make each one a button.
          return part.split(/(\s+)/).map((word, wordIndex) => {
             if (/\S/.test(word)) {
                const cleanWord = word.replace(/[.,!?;:()"']/g, '');
                // It's possible a single word here is ALSO a known topic. Check that.
                const isKnownTopic = topicMap.has(cleanWord.toLowerCase());
                const buttonClassName = `interactive-word ${isKnownTopic ? 'known-topic' : ''}`.trim();
                return (
                    <button
                        key={`${index}-${wordIndex}`}
                        onClick={() => onWordClick(cleanWord)}
                        className={buttonClassName}
                        aria-label={`Learn more about ${cleanWord}`}
                    >
                        {word}
                    </button>
                );
             }
             // Render whitespace as-is
             return <span key={`${index}-${wordIndex}`}>{word}</span>
          });
        }
      })}
    </p>
  );
};


const StreamingContent: React.FC<{ content: string }> = ({ content }) => (
  <p style={{ margin: 0 }}>
    {content}
    <span className="blinking-cursor">|</span>
  </p>
);

const ContentDisplay: React.FC<ContentDisplayProps> = ({ content, isLoading, onWordClick, knownTopics }) => {
  if (isLoading) {
    return <StreamingContent content={content} />;
  }
  
  if (content) {
    return <InteractiveContent content={content} onWordClick={onWordClick} knownTopics={knownTopics} />;
  }

  return null;
};

export default ContentDisplay;