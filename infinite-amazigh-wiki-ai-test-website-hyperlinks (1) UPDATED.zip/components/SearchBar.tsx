/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState } from 'react';

interface SearchBarProps {
  onSearch: (query: string) => void;
  onRandom: () => void;
  isLoading: boolean;
  onBack: () => void;
  onForward: () => void;
  canGoBack: boolean;
  canGoForward: boolean;
}

const SearchBar: React.FC<SearchBarProps> = ({ 
  onSearch, 
  onRandom, 
  isLoading,
  onBack,
  onForward,
  canGoBack,
  canGoForward
}) => {
  const [query, setQuery] = useState('');

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (query.trim() && !isLoading) {
      onSearch(query.trim());
      setQuery(''); // Clear the input field after search
    }
  };

  return (
    <div className="search-container">
      <form onSubmit={handleSubmit} className="search-form" role="search">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search"
          className="search-input"
          aria-label="Search for a topic"
          disabled={isLoading}
        />
      </form>
      <div className="search-controls">
        <button onClick={onBack} className="history-button" disabled={isLoading || !canGoBack} aria-label="Go back">&lt;</button>
        <button onClick={onForward} className="history-button" disabled={isLoading || !canGoForward} aria-label="Go forward">&gt;</button>
        <button onClick={onRandom} className="random-button" disabled={isLoading} aria-label="Go to a random topic">
          Random
        </button>
      </div>
    </div>
  );
};

export default SearchBar;