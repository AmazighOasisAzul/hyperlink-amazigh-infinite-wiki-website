/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState, useEffect, useCallback } from 'react';
import { streamDefinition, generateAsciiArt, AsciiArtData } from './services/geminiService';
import ContentDisplay from './components/ContentDisplay';
import SearchBar from './components/SearchBar';
import LoadingSkeleton from './components/LoadingSkeleton';
import AsciiArtDisplay from './components/AsciiArtDisplay';

// A greatly expanded list of topics for the random button, curated from research on Amazigh culture,
// inspired by sources like Wikipedia and wiki.amazigh.com.
const PREDEFINED_WORDS = [
  // Core Identity & Language
  'Amazigh', 'Imazighen', 'Amazighity', 'Berber', 'Tamazight', 'Tifinagh', 'Libyco-Berber script', 'Neo-Tifinagh', 'Standard Moroccan Amazigh', 'Kabyle language', 'Shilha language (Tashelhit)', 'Central Atlas Tamazight', 'Riffian language (Tarifit)', 'Chaoui language (Tachawit)', 'Tuareg languages (Tamasheq)', 'Siwi language', 'Guanche language', 'Zenaga language',

  // Major Groups & Tribes
  'Kabyle', 'Tuareg', 'Rifian', 'Shilha', 'Chaoui', 'Siwi', 'Zenata', 'Sanhaja', 'Masmuda', 'Ghomara', 'Drawa', 'Nafusa', 'Guanches',

  // Geography & Homeland (Tamazgha)
  'Tamazgha', 'Maghreb', 'North Africa', 'Atlas Mountains', 'High Atlas', 'Middle Atlas', 'Anti-Atlas', 'Rif Mountains', 'Sahara Desert', 'Sahel', 'Tassili n\'Ajjer', 'Hoggar Mountains', 'Aïr Mountains', 'Siwa Oasis', 'Canary Islands', 'Nafusa Mountains', 'Aurès Mountains',

  // Ancient History & Kingdoms
  'Numidia', 'Mauretania', 'Garamantes', 'Libu', 'Meshwesh', 'Gaetuli', 'Massinissa', 'Jugurtha', 'Juba I', 'Juba II', 'Cleopatra Selene II', 'Bocchus I', 'Tacfarinas',

  // Medieval & Early Modern History
  'Dihya (al-Kahina)', 'Kusaila (Aksil)', 'Tariq ibn Ziyad', 'Almoravid dynasty', 'Almohad Caliphate', 'Ibn Tumart', 'Zirid dynasty', 'Hammadid dynasty', 'Kingdom of Tlemcen', 'Marinid Sultanate', 'Barbary pirates', 'Islamic conquests',

  // Mythology & Religion
  'Anzar (God of rain)', 'Tafukt (Goddess of sun)', 'Tiziri (Goddess of moon)', 'Gurzil (God of war)', 'Ifri', 'Libyan mythology', 'Traditional Amazigh religion', 'Syncretism', 'Maraboutism',

  // Culture, Arts & Society
  'Fantasia (Tbourida)', 'Ahwash', 'Ahouach', 'Izlan', 'Berber music', 'Gnawa music', 'Tagine', 'Couscous', 'Smen', 'Amlou', 'Berber tea ceremony', 'Henna tattoos (Harqus)', 'Tattoos (Tirad)', 'Amazigh jewelry', 'Fibula (Tizerzai)', 'Berber carpets', 'Kilim', 'Burnous', 'Djellaba', 'Kaftan', 'Tribal law (Qanun)', 'Agraw (council)', 'Laṣel (customs)',

  // Symbols & Amulets
  'Yaz symbol (ⵣ)', 'Fibula', 'Khamsa (Hand of Fatima)', 'Tanit symbol', 'Amazigh flag', 'Berber cross',

  // Modern Era & Activism
  'Berberism (Amazighism)', 'Amazigh Cultural Movement (MCA)', 'World Amazigh Congress', 'Berber Spring (Tafsut Imazighen)', 'Black Spring (2001)', 'Royal Institute of Amazigh Culture (IRCAM)', 'Haut-Commissariat à l\'Amazighité (HCA)', 'Matoub Lounès', 'Mohand ou-Lhocine',

  // Notable Cities & Sites
  'Marrakech', 'Tizi Ouzou', 'Agadir', 'Ghardaïa', 'Tinghir', 'Volubilis', 'Tiddis', 'Sijilmasa', 'Djanet', 'Ghadames', 'Timbuktu', 'Fez', 'Meknes', 'Essaouira', 'Chefchaouen'
];
const UNIQUE_WORDS = [...new Set(PREDEFINED_WORDS)];


/**
 * Creates a simple ASCII art bounding box as a fallback.
 * @param topic The text to display inside the box.
 * @returns An AsciiArtData object with the generated art.
 */
const createFallbackArt = (topic: string): AsciiArtData => {
  const displayableTopic = topic.length > 20 ? topic.substring(0, 17) + '...' : topic;
  const paddedTopic = ` ${displayableTopic} `;
  const topBorder = `┌${'─'.repeat(paddedTopic.length)}┐`;
  const middle = `│${paddedTopic}│`;
  const bottomBorder = `└${'─'.repeat(paddedTopic.length)}┘`;
  return {
    art: `${topBorder}\n${middle}\n${bottomBorder}`
  };
};

const App: React.FC = () => {
  const [history, setHistory] = useState<string[]>(['Amazigh']);
  const [historyIndex, setHistoryIndex] = useState<number>(0);
  const currentTopic = history[historyIndex];

  const [content, setContent] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [asciiArt, setAsciiArt] = useState<AsciiArtData | null>(null);
  const [generationTime, setGenerationTime] = useState<number | null>(null);
  const [shufflingTopic, setShufflingTopic] = useState<string | null>(null);

  useEffect(() => {
    if (!currentTopic) return;

    let isCancelled = false;

    const fetchContentAndArt = async () => {
      // Set initial state for a clean page load
      setIsLoading(true);
      setError(null);
      setContent(''); // Clear previous content immediately
      setAsciiArt(null);
      setGenerationTime(null);
      const startTime = performance.now();

      // Kick off ASCII art generation, but don't wait for it.
      // It will appear when it's ready, without blocking the definition.
      generateAsciiArt(currentTopic)
        .then(art => {
          if (!isCancelled) {
            setAsciiArt(art);
          }
        })
        .catch(err => {
          if (!isCancelled) {
            console.error("Failed to generate ASCII art:", err);
            // Generate a simple fallback ASCII art box on failure
            const fallbackArt = createFallbackArt(currentTopic);
            setAsciiArt(fallbackArt);
          }
        });

      let accumulatedContent = '';
      try {
        for await (const chunk of streamDefinition(currentTopic)) {
          if (isCancelled) break;
          
          if (chunk.startsWith('Error:')) {
            throw new Error(chunk);
          }
          accumulatedContent += chunk;
          if (!isCancelled) {
            setContent(accumulatedContent);
          }
        }
      } catch (e: unknown) {
        if (!isCancelled) {
          const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred';
          setError(errorMessage);
          setContent(''); // Ensure content is clear on error
          console.error(e);
        }
      } finally {
        if (!isCancelled) {
          const endTime = performance.now();
          setGenerationTime(endTime - startTime);
          setIsLoading(false);
        }
      }
    };

    fetchContentAndArt();
    
    return () => {
      isCancelled = true;
    };
  }, [currentTopic]);

  const navigateToTopic = useCallback((topic: string) => {
    const newTopic = topic.trim();
    if (newTopic && newTopic.toLowerCase() !== currentTopic.toLowerCase()) {
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push(newTopic);
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
    }
  }, [currentTopic, history, historyIndex]);

  const handleWordClick = useCallback((word: string) => {
    navigateToTopic(word);
  }, [navigateToTopic]);

  const handleSearch = useCallback((topic: string) => {
    navigateToTopic(topic);
  }, [navigateToTopic]);

  const handleRandom = useCallback(() => {
    const shuffleDuration = 500; // ms
    const shuffleInterval = 50; // ms
    let elapsed = 0;

    const intervalId = setInterval(() => {
        const randomIndex = Math.floor(Math.random() * UNIQUE_WORDS.length);
        setShufflingTopic(UNIQUE_WORDS[randomIndex]);
        elapsed += shuffleInterval;
        if (elapsed >= shuffleDuration) {
            clearInterval(intervalId);
            
            // Pick the final word, ensuring it's not the same as the current one
            let randomWord: string;
            do {
                const finalRandomIndex = Math.floor(Math.random() * UNIQUE_WORDS.length);
                randomWord = UNIQUE_WORDS[finalRandomIndex];
            } while (UNIQUE_WORDS.length > 1 && randomWord.toLowerCase() === currentTopic.toLowerCase());
            
            // Navigate and clean up
            navigateToTopic(randomWord);
            setShufflingTopic(null);
        }
    }, shuffleInterval);
  }, [currentTopic, navigateToTopic]);
  
  const handleBack = useCallback(() => {
    if (historyIndex > 0) {
      setHistoryIndex(prev => prev - 1);
    }
  }, [historyIndex]);

  const handleForward = useCallback(() => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(prev => prev + 1);
    }
  }, [historyIndex, history]);

  const handleTitleClick = useCallback(() => {
    if (isLoading) return;
    const homeTopic = 'Amazigh';
    if (currentTopic.toLowerCase() !== homeTopic.toLowerCase()) {
      setHistory([homeTopic]);
      setHistoryIndex(0);
    }
  }, [currentTopic, isLoading]);

  return (
    <div>
      <SearchBar 
        onSearch={handleSearch} 
        onRandom={handleRandom} 
        isLoading={isLoading || !!shufflingTopic} 
        onBack={handleBack}
        onForward={handleForward}
        canGoBack={historyIndex > 0}
        canGoForward={historyIndex < history.length - 1}
      />
      
      <header style={{ textAlign: 'center', marginBottom: '2rem' }}>
        <button onClick={handleTitleClick} className="title-button" disabled={isLoading} aria-label="Go to home page">
            <h1 style={{ letterSpacing: '0.2em' }}>
              ⵣ INFINITE WIKI ⵣ
            </h1>
        </button>
        <AsciiArtDisplay artData={asciiArt} topic={currentTopic} />
      </header>
      
      <main>
        <div>
          <h2 style={{ marginBottom: '2rem', textTransform: 'capitalize' }}>
            <span className={shufflingTopic ? 'shuffling-topic' : ''}>
              {shufflingTopic || currentTopic}
            </span>
          </h2>

          {error && (
            <div style={{ border: '1px solid #cc0000', padding: '1rem', color: '#cc0000' }}>
              <p style={{ margin: 0 }}>An Error Occurred</p>
              <p style={{ marginTop: '0.5rem', margin: 0 }}>{error}</p>
            </div>
          )}
          
          {isLoading && content.length === 0 && !error && (
            <LoadingSkeleton />
          )}

          {content.length > 0 && !error && (
             <ContentDisplay 
               content={content} 
               isLoading={isLoading} 
               onWordClick={handleWordClick} 
               knownTopics={UNIQUE_WORDS}
             />
          )}

          {!isLoading && !error && content.length === 0 && (
            <div style={{ color: '#888', padding: '2rem 0' }}>
              <p>Content could not be generated.</p>
            </div>
          )}
        </div>
      </main>

      <footer className="sticky-footer">
        <p className="footer-text" style={{ margin: 0 }}>
          Amazigh Infinite Hyperlink by Azulwebg · Generated by Gemini 2.5 Flash Lite · Dev Valladares
          {generationTime && ` · ${Math.round(generationTime)}ms`}
           · <a href="https://discord.gg/BuAg58GHAD" target="_blank" rel="noopener noreferrer" aria-label="Join our Discord community">Join the Community</a>
        </p>
      </footer>
    </div>
  );
};

export default App;